NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2
# S1
x          =   0.0
y          =   0.0
z          =  -1.5473

sigma      =   3.8683
epsilon    = 274.97
mass       =  86.918
# S2
x          =   0.0
y          =   0.0
z          =   1.5473

sigma      =   3.8683
epsilon    = 274.97
mass       =  86.918

SiteType   =   Q
NSites     =   1
# S3
x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
quadrupole =   9.2682
mass       =   0.0
shielding  =   0.77366

NRotAxes   =   auto
