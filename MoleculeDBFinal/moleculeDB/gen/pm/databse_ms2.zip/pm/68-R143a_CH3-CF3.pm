NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x  =  0.0
y  =  0.0
z  =  -1.76975
sigma  =  3.5960
epsilon  =  165.04
mass  =  42.00

# {X}(2)
x  =  0.0
y  =  0.0
z  =  1.76975
sigma  =  3.5960
epsilon  =  165.04
mass  =  42.00

SiteType   =  Dipole
NSites   =  1


# d
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
dipole  =  2.7470
mass  =  0.0
shielding  =  0.7192
