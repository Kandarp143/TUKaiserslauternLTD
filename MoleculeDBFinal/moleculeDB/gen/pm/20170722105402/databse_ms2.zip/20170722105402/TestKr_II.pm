NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  1


# Kr
x   =  0.0
y   =  0.0
z   =  0.0
sigma   =  3.6233
epsilon   =  191.52
mass   =  83.798

NRotAxes   =   auto