NSiteTypes   =  2


# {X} (1)
x  =  0.0
y  =  0.0
z  =  -1.31875
sigma  =  3.9615
epsilon  =  118.98
mass  =  73.028

# {X} (2)
x  =  0.0
y  =  0.0
z  =  1.31875
sigma  =  3.9615
epsilon  =  118.98
mass  =  73.028

SiteType   =  Quadrupole
NSites   =  1


# q
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
quadrupole  =  8.0066
mass  =  0.0
shielding  =  0.7923
