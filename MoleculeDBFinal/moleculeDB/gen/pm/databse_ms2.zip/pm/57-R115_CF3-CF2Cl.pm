NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x  =  0.0
y  =  0.0
z  =  -1.67565
sigma  =  4.1891
epsilon  =  155.77
mass  =  77.233

# {X}(2)
x  =  0.0
y  =  0.0
z  =  1.67565
sigma  =  4.1891
epsilon  =  155.77
mass  =  77.233

SiteType   =  Quadrupole
NSites   =  1


# q
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
quadrupole  =  9.2246
mass  =  0.0
shielding  =  0.83782
