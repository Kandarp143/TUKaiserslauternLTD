NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2
# S1
x          =   0.0
y          =   0.0
z          =  -1.31785

sigma      =   4.4120
epsilon    = 201.03
mass       =  65.694
# S2
x          =   0.0
y          =   0.0
z          =   1.31785

sigma      =   4.4120
epsilon    = 201.03
mass       =  65.694

SiteType   =   Q
NSites     =   1
# S3
x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
quadrupole =  13.624
mass       =   0.0
shielding  =   0.8824

NRotAxes   =   auto
