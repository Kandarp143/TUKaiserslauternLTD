NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  1


# CH4
x   =  0.0
y   =  0.0
z   =  0.0
sigma   =  3.7241
epsilon   =  175.06
mass   =  16.043

NRotAxes   =   auto