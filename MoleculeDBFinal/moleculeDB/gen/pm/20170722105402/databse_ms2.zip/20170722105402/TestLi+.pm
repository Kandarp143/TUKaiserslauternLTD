NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  1


# Li_1+
x   =  0.0
y   =  0.0
z   =  0.0
sigma   =  1.88
epsilon   =  200
mass   =  6.940

SiteType   =  Charge
NSites   =  1


# e
x   =  0.0
y   =  0.0
z   =  0.0
charge   =  +1.0000
mass   =  0.0
shielding   =  0.71092

NRotAxes   =   auto