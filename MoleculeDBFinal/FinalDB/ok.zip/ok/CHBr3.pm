NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2

x          =   0.0
y          =   0.0
z          =  -1.97115

sigma      =   4.0575
epsilon    = 357.41
mass       = 126.366


x          =   0.0
y          =   0.0
z          =   1.97115

sigma      =   4.0575
epsilon    = 357.41
mass       = 126.366

SiteType   =   D
NSites     =   1

x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
dipole     =   3.5204
mass       =   0.0
shielding  =   0.8115

NRotAxes   =   auto
