NSiteTypes =   2

SiteType   =   LJ126
NSites     =   5
# S1 
x          =   0.0
y          =   0.0
z          =   0.0
sigma      =   2.81
epsilon    =   12.37
mass       =  12.011
# S2
x          =   1.18
y          =   1.18
z          =   1.18
sigma      =   3.25
epsilon    = 212.6
mass       =  35.453
# S3
x          =   -1.18
y          =   -1.18
z          =   1.18
sigma      =   3.25
epsilon    = 212.6
mass       =  35.453

# S4
x          =   -1.18
y          =   1.18
z          =   -1.18
sigma      =   3.25
epsilon    = 212.6
mass       =  35.453
# S5
x          =   1.18
y          =   -1.18
z          =   -1.18
sigma      =   3.25
epsilon    = 212.6
mass       =  35.453


SiteType   =   Charge
NSites     =   5
# S6
x          =   0.0
y          =   0.0
z          =   0.0
charge     =   -0.362
mass       =   0.0
shielding  =   0.1
# S7
x          =   1.18
y          =   1.18
z          =   1.18
charge     =   0.0905
mass       =   0.0
shielding  =   0.1
# S8
x          =   -1.18
y          =   -1.18
z          =   1.18
charge     =   0.0905
mass       =   0.0
shielding  =   0.1
# S9
x          =   -1.18
y          =   1.18
z          =   -1.18
charge     =   0.0905
mass       =   0.0
shielding  =   0.1
# S10
x          =   1.18
y          =   -1.18
z          =   -1.18
charge     =   0.0905
mass       =   0.0
shielding  =   0.1


NRotAxes   =   auto

NFluct = 7
1.000   1.000   1.000   0.700
0.900   0.900   0.900   0.450
0.700   0.800   0.800   0.250
0.500   0.650   0.600   0.100
0.350   0.550   0.400   0.000
0.200   0.400   0.200   0.000
0.000   0.000   0.000   0.000




