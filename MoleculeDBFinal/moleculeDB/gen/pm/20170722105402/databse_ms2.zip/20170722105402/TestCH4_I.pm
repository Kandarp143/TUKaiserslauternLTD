NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  1


# CH4
x   =  0.0
y   =  0.0
z   =  0.0
sigma   =  3.7281
epsilon   =  148.55
mass   =  16.043

NRotAxes   =   auto