NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  3


# CH2(1)
x   =  0
y   =  0
z   =  0
sigma   =  3.56655516
epsilon   =  87.14905608
mass   =  14.03

# CH2(2)
x   =  0.84315
y   =  1.46037863840169
z   =  0
sigma   =  3.56655516
epsilon   =  87.14905608
mass   =  14.03

# CH2(3)
x   =  1.6863
y   =  0
z   =  0
sigma   =  3.56655516
epsilon   =  87.14905608
mass   =  14.03

NRotAxes   =   auto