NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x   =  0.0
y   =  0.0
z   =  -1.80075
sigma   =  4.0209
epsilon   =  231.43
mass   =  58.475

# {X}(2)
x   =  0.0
y   =  0.0
z   =  1.80075
sigma   =  4.0209
epsilon   =  231.43
mass   =  58.475

SiteType   =  Dipole
NSites   =  1


# d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  3.1484
mass   =  0.0
shielding   =  0.80418

NRotAxes   =   auto