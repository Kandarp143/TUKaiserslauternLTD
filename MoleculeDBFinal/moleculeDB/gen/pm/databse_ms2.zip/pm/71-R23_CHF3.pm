NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  2


# {X}(2)
epsilon  =  123.56
mass  =  35.007

SiteType   =  Dipole
NSites   =  1


# d
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
dipole  =  2.1607
mass  =  0.0
shielding  =  0.65286

SiteType   =  LJ126
NSites   =  2


# {X}(1)
x  =  0.0
y  =  0.0
z  =  -1.2835
sigma  =  3.2643
epsilon  =  123.56
mass  =  35.007

# {X}(2)
x  =  0.0
y  =  0.0
z  =  1.2835
sigma  =  3.2643
