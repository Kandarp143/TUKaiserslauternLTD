NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# F (1)
x   =  0.0
y   =  0.0
z   =  -0.70645
sigma   =  2.8258
epsilon   =  52.147
mass   =  18.998

# F (2)
x   =  0.0
y   =  0.0
z   =  0.70645
sigma   =  2.8258
epsilon   =  52.147
mass   =  18.998

SiteType   =  Quadrupole
NSites   =  1


# q
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
quadrupole   =  0.8920
mass   =  0.0
shielding   =  0.56516

NRotAxes   =   auto