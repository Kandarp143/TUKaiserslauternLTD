NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# CHCl2(1)
x   =  0.0
y   =  0.0
z   =  -2.06305
sigma   =  4.3282
epsilon   =  292.86
mass   =  83.925

# CHCl2(2)
x   =  0.0
y   =  0.0
z   =  2.06305
sigma   =  4.3282
epsilon   =  292.86
mass   =  83.925

SiteType   =  Dipole
NSites   =  1


# d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  4.7919
mass   =  0.0
shielding   =  0.86564

NRotAxes   =   auto