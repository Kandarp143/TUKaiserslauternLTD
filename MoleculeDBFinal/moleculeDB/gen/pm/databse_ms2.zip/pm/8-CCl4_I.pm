NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  2


# {X} (1)
x  =  0.0
y  =  0.0
z  =  -0.8473
sigma  =  4.8471
epsilon  =  142.14
mass  =  76.912

# {X} (2)
x  =  0.0
y  =  0.0
z  =  0.8473
sigma  =  4.8471
epsilon  =  142.14
mass  =  76.912

SiteType   =  Quadrupole
NSites   =  1


# q
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
quadrupole  =  14.346
mass  =  0.0
shielding  =  0.96942
