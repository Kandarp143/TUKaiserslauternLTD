NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2
# S1
x          =   0.0
y          =   0.0
z          =  -1.3623

sigma      =   4.1282
epsilon    = 110.19
mass       =  69.006
# S2
x          =   0.0
y          =   0.0
z          =   1.3623

sigma      =   4.1282
epsilon    = 110.19
mass       =  69.006

SiteType   =   Q
NSites     =   1
# S3
x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
quadrupole =  -8.4943
mass       =   0.0
shielding  =   0.82564

NRotAxes   =   auto
