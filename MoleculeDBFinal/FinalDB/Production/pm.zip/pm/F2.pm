NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2
# S1
x          =   0.0
y          =   0.0
z          =  -0.70645

sigma      =   2.8258
epsilon    =  52.147
mass       =  18.998
# S2
x          =   0.0
y          =   0.0
z          =   0.70645

sigma      =   2.8258
epsilon    =  52.147
mass       =  18.998

SiteType   =   Q
NSites     =   1
# S3
x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
quadrupole =   0.8920
mass       =   0.0
shielding  =   0.56516

NRotAxes   =   auto
