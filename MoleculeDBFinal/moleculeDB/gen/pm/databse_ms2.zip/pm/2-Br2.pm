NSiteTypes   =  2


# Br (1)
x  =  0.0
y  =  0.0
z  =  -1.08885
sigma  =  3.5546
epsilon  =  236.76
mass  =  79.904

# Br (2)
x  =  0.0
y  =  0.0
z  =  1.08885
sigma  =  3.5546
epsilon  =  236.76
mass  =  79.904

SiteType   =  Quadrupole
NSites   =  1


# q
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
quadrupole  =  4.8954
mass  =  0.0
shielding  =  0.71092
