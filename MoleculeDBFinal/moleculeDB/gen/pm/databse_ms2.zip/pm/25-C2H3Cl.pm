NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x  =  0.0
y  =  0.0
z  =  -1.25245
sigma  =  3.6875
epsilon  =  181.16
mass  =  31.249

# {X}(2)
x  =  0.0
y  =  0.0
z  =  1.25245
sigma  =  3.6875
epsilon  =  181.16
mass  =  31.249

SiteType   =  Dipole
NSites   =  1


# d
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
dipole  =  2.1078
mass  =  0.0
shielding  =  0.7375
