NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2

# S1
x          =   0.0
y          =   0.0
z          =  -1.3392

sigma      =   3.7200
epsilon    = 371.47
mass       = 126.904

# S2
x          =   0.0
y          =   0.0
z          =   1.3392

sigma      =   3.7200
epsilon    = 371.47
mass       = 126.904

SiteType   =   Q
NSites     =   1

# S3
x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
quadrupole =   5.6556
mass       =   0.0
shielding  =   0.7440

NRotAxes   =   auto
