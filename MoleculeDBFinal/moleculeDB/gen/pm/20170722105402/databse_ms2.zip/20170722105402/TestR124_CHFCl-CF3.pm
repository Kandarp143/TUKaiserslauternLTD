NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x   =  0.0
y   =  0.0
z   =  -1.9426
sigma   =  3.8852
epsilon   =  192.25
mass   =  68.238

# {X}(2)
x   =  0.0
y   =  0.0
z   =  1.9426
sigma   =  3.8852
epsilon   =  192.25
mass   =  68.238

SiteType   =  Dipole
NSites   =  1


# d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  3.2190
mass   =  0.0
shielding   =  0.77704

NRotAxes   =   auto