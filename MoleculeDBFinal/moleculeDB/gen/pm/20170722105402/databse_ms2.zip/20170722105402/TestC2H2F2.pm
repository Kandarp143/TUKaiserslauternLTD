NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x   =  0.0
y   =  0.0
z   =  -0.74315
sigma   =  3.7848
epsilon   =  71.963
mass   =  32.017

# {X}(2)
x   =  0.0
y   =  0.0
z   =  0.74315
sigma   =  3.7848
epsilon   =  71.963
mass   =  32.017

SiteType   =  Dipole
NSites   =  1


# d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  2.3643
mass   =  0.0
shielding   =  0.75696

NRotAxes   =   auto