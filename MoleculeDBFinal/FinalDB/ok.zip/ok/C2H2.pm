NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2

x          =   0.0
y          =   0.0
z          =  -0.6499

sigma      =   3.5742
epsilon    =  79.890
mass       =  13.019

x          =   0.0
y          =   0.0
z          =   0.6499

sigma      =   3.5742
epsilon    =  79.890
mass       =  13.019

SiteType   =   Q
NSites     =   1

x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
quadrupole =   5.0730
mass       =   0.0
shielding  =   0.71484

NRotAxes   =   auto
