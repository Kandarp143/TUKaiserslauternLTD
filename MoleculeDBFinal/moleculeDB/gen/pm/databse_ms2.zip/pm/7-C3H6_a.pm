NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  2


# {X} (1)
x  =  0.0
y  =  0.0
z  =  -1.2507
sigma  =  3.8169
epsilon  =  150.78
mass  =  21.040

# {X} (2)
x  =  0.0
y  =  0.0
z  =  1.2507
sigma  =  3.8169
epsilon  =  150.78
mass  =  21.040

SiteType   =  Quadrupole
NSites   =  1


# q
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
quadrupole  =  5.9387
mass  =  0.0
shielding  =  0.76338
