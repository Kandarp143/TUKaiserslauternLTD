NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  1


# CH2Br2
x  =  0.0
y  =  0.0
z  =  0.0
sigma  =  4.7376
epsilon  =  351.03
mass  =  174.00

SiteType   =  Dipole
NSites   =  1


# d
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
dipole  =  3.7104
mass  =  0.0
shielding  =  0.94752
