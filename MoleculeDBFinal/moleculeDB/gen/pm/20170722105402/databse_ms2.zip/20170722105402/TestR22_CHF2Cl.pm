NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x   =  0.0
y   =  0.0
z   =  -1.56015
sigma   =  3.4682
epsilon   =  177.43
mass   =  43.234

# {X}(2)
x   =  0.0
y   =  0.0
z   =  1.56015
sigma   =  3.4682
epsilon   =  177.43
mass   =  43.234

SiteType   =  Dipole
NSites   =  1


# d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  2.2667
mass   =  0.0
shielding   =  0.69364

NRotAxes   =   auto