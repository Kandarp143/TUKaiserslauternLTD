NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  2


# CH2 (1)
x  =  0.0
y  =  0.0
z  =  -0.63475
sigma  =  3.7607
epsilon  =  76.950
mass  =  14.027

# CH2  (2)
x  =  0.0
y  =  0.0
z  =  0.63475
sigma  =  3.7607
epsilon  =  76.950
mass  =  14.027

SiteType   =  Quadrupole
NSites   =  1


# q
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
quadrupole  =  4.3310
mass  =  0.0
shielding  =  0.75214
