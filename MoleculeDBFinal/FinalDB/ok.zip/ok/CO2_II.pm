NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2

x          =   0.0
y          =   0.0
z          =  -1.2088

sigma      =   2.9847
epsilon    = 133.22
mass       =  22.005

x          =   0.0
y          =   0.0
z          =   1.2088

sigma      =   2.9847
epsilon    = 133.22
mass       =  22.005

SiteType   =   Q
NSites     =   1

x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
quadrupole =  -3.7938
mass       =   0.0
shielding  =   0.59694

NRotAxes   =   auto
