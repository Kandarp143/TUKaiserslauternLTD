NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2

# S1
x          =   0.0
y          =   0.0
z          =  -1.76975

sigma      =   3.5960
epsilon    = 165.04
mass       =  42.00

# S2
x          =   0.0
y          =   0.0
z          =   1.76975

sigma      =   3.5960
epsilon    = 165.04
mass       =  42.00

SiteType   =   D
NSites     =   1

# S3
x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
dipole     =   2.7470
mass       =   0.0
shielding  =   0.7192

NRotAxes   =   auto
