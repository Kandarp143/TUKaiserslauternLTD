NSiteTypes   =  2

y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
quadrupole  =  0.8277
mass  =  0.0
shielding  =  1.00

SiteType   =  LJ126
NSites   =  2


# CH3(1)
x  =  0.0
y  =  0.0
z  =  -1.1881
sigma  =  3.4896
epsilon  =  136.99
mass  =  15.035

# CH3(2)
x  =  0.0
y  =  0.0
z  =  1.1881
sigma  =  3.4896
epsilon  =  136.99
mass  =  15.035

SiteType   =  Quadrupole
NSites   =  1


# q
x  =  0.0
