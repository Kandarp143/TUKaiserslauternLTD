NSiteTypes =   2

SiteType   =   LJ126
NSites     =   2

# S1
x          =   0.0
y          =   0.0
z          =  -1.5369

sigma      =   3.6184
epsilon    = 145.95
mass       =  52.230

# S2
x          =   0.0
y          =   0.0
z          =   1.5369

sigma      =   3.6184
epsilon    = 145.95
mass       =  52.230

SiteType   =   D
NSites     =   1

# S3
x          =   0.0
y          =   0.0
z          =   0.0
theta      =   0.0
phi        =   0.0
dipole     =   1.8261
mass       =   0.0
shielding  =   0.72368

NRotAxes   =   auto
