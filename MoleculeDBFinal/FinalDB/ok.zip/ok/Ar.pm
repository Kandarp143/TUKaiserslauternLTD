NSiteTypes =   1

SiteType   =   LJ126
NSites     =   1

# Ar
x          =   0.0
y          =   0.0
z          =   0.0
sigma      =   3.3952
epsilon    = 116.79
mass       =  39.948

NRotAxes   =   auto
