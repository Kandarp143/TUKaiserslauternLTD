NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x   =  0.0
y   =  0.0
z   =  -1.7449
sigma   =  4.2224
epsilon   =  253.75
mass   =  66.702

# {X}(2)
x   =  0.0
y   =  0.0
z   =  1.7449
sigma   =  4.2224
epsilon   =  253.75
mass   =  66.702

SiteType   =  Dipole
NSites   =  1


# d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  3.5019
mass   =  0.0
shielding   =  0.84448

NRotAxes   =   auto