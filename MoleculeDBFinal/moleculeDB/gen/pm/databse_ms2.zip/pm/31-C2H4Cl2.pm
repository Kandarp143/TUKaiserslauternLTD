NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x  =  0.0
y  =  0.0
z  =  -1.90675
sigma  =  3.8579
epsilon  =  255.24
mass  =  49.480

# {X}(2)
x  =  0.0
y  =  0.0
z  =  1.90675
sigma  =  3.8579
epsilon  =  255.24
mass  =  49.480

SiteType   =  Dipole
NSites   =  1


# d
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
dipole  =  3.5236
mass  =  0.0
shielding  =  0.77158
