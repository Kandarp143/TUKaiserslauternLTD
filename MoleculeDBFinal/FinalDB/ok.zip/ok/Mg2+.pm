NSiteTypes =   2

SiteType   =   LJ126
NSites     =   1

# Mg 2+
x          =   0.0
y          =   0.0
z          =   0.0

sigma      =   1.77  
epsilon    = 200.00
mass       =  24.305

SiteType   =   Charge
NSites     =   1

x          =   0.0
y          =   0.0
z          =   0.0
charge     =   2.0000
mass       =   0.0
shielding  =   0.71092

NRotAxes   =   auto
