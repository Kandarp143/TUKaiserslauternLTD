NSiteTypes   =  2


SiteType   =  LJ126
NSites   =  2


# CF2Cl(1)
x  =  0.0
y  =  0.0
z  =  -1.7509
sigma  =  4.3772
epsilon  =  183.26
mass  =  85.461

# CF2Cl(2)
x  =  0.0
y  =  0.0
z  =  1.7509
sigma  =  4.3772
epsilon  =  183.26
mass  =  85.461

SiteType   =  Quadrupole
NSites   =  1


# q
x  =  0.0
y  =  0.0
z  =  0.0
theta  =  0.0
phi  =  0.0
quadrupole  =  11.456
mass  =  0.0
shielding  =  0.87544
