NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X} (1)
x   =  0.0
y   =  0.0
z   =  -1.2479
sigma   =  3.6367
epsilon   =  170.52
mass   =  20.032

# {X} (2)
x   =  0.0
y   =  0.0
z   =  1.2479
sigma   =  3.6367
epsilon   =  170.52
mass   =  20.032

SiteType   =  Quadrupole
NSites   =  1


# q
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
quadrupole   =  5.1637
mass   =  0.0
shielding   =  0.72734

NRotAxes   =   auto